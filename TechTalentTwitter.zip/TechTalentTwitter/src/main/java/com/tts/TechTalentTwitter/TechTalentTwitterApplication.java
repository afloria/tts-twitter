package com.tts.TechTalentTwitter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechTalentTwitterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechTalentTwitterApplication.class, args);
	}

}
